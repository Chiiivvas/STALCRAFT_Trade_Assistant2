"""Движок распознавания с двумя уровнями.

БЫСТРЫЙ режим (fast_scan, миллисекунды, без Tesseract):
    поиск карточек -> иконка по шаблонам -> количество/вес по шаблонам цифр -> цена из базы.
    Результат предварительный: позиции получают статус «проверяется».
ПОЛНЫЙ режим (verify, в фоне):
    Tesseract-перепроверка количества, чтение списка слева, вес, расширенное чтение для
    сомнительных случаев. Только после него позиция становится «уверенно распознано».

Принцип точности не изменился: в подтверждённый итог попадает только позиция с уверенной
иконкой, прочитанным количеством, без противоречий и с независимым подтверждением
(список слева / вес стопки). Противоречие быстрого и полного режима -> «требуется проверка».
"""
from __future__ import annotations

import dataclasses
import hashlib
import threading
import time
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
from typing import Callable

import cv2
import numpy as np

from .config import Config
from .item_matcher import NameIndex
from .models import (CHECK, OK, PENDING, UNRECOGNIZED, CardReading, ItemResult, RawRead,
                     ScanResult, Timings)
from .paths import ASSETS_DIR, data_dir
from .price_database import Catalog
from .vision.digits import DigitReader
from .vision.grid import detect_grid
from .vision.icons import IconMatcher
from .vision.list_reader import read_list, text_mask
from .vision.ocr import OcrEngine, OcrError
from .vision.quantity import ReadResult, read_quantity, read_weight

UNKNOWN_ICON_SCORE = 0.55     # ниже — предмет явно не из базы
MAX_VERIFIED_GROUPS = 512


def _sem(card: CardReading) -> tuple[int, int]:
    """Смысловая подпись карточки (количество, вес) — устойчива к подсветке при наведении мыши."""
    raw = card.raw
    q = raw.qty.value if raw and raw.qty.ok else -1
    w = raw.weight.value if raw and raw.weight and raw.weight.ok else -1
    return (q, w)


class ScanEngine:
    def __init__(self, config: Config, ocr: OcrEngine, digits: DigitReader | None = None,
                 cache_size: int = 512) -> None:
        self.cfg = config
        self.ocr = ocr
        self.digits = digits if digits is not None else DigitReader(ASSETS_DIR / "digits",
                                                                    data_dir() / "digits")
        self.catalog = Catalog({}, 0)
        self._matcher = IconMatcher()
        self._index = NameIndex({})
        self._cache: OrderedDict[str, RawRead] = OrderedDict()
        self._cache_size = cache_size
        self._verified_groups: OrderedDict[tuple, bool] = OrderedDict()
        self._verified_reads: set[tuple] = set()
        self._lock = threading.RLock()
        self._pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix="ocr")
        self._list_cache: tuple[np.ndarray, object] | None = None

    # ---- настройка ----------------------------------------------------------
    def set_catalog(self, catalog: Catalog) -> None:
        self.catalog = catalog
        self._matcher.set_templates(catalog.template_images())
        self._index = catalog.name_index()
        self.clear_cache()

    def clear_cache(self) -> None:
        with self._lock:
            self._cache.clear()
            self._verified_groups.clear()
            self._verified_reads.clear()
            self._list_cache = None

    def drop_list_cache(self) -> None:
        with self._lock:
            self._list_cache = None

    def close(self) -> None:
        self._pool.shutdown(wait=False, cancel_futures=True)

    @staticmethod
    def _key(cell: np.ndarray) -> str:
        return hashlib.md5(cell.tobytes() + bytes(str(cell.shape), "ascii")).hexdigest()

    def _name(self, item_id: str | None) -> str:
        it = self.catalog.items.get(item_id) if item_id else None
        return it.name if it else "?"

    # ======================================================================
    # БЫСТРЫЙ РЕЖИМ
    # ======================================================================
    def _read_cell_fast(self, img: np.ndarray, partial: bool, t: Timings) -> tuple[RawRead, bool]:
        key = self._key(img)
        with self._lock:
            raw = self._cache.get(key)
            if raw is not None:
                self._cache.move_to_end(key)
                return raw, True
        with t.span("icons"):
            icon = self._matcher.match(img)
        if partial:
            raw = RawRead(icon, ReadResult(reason="карточка обрезана"), None, verified=True)
        else:
            with t.span("qty_fast"):
                dq = self.digits.read_qty(img)
                dw = self.digits.read_weight(img) if self.cfg.use_weight_check else None
            qty = ReadResult(dq.value, [dq.text], {}, 1.0 if dq.ok else 0.0, "digits",
                             "" if dq.ok else (dq.reason or "не прочитано"))
            weight = (ReadResult(dw.value, [dw.text], {}, 1.0, "digits")
                      if dw is not None and dw.ok else None)
            raw = RawRead(icon, qty, weight, False, qty_src="digits" if dq.ok else "")
            sem = (icon.best_id, qty.value, weight.value if weight else None)
            if qty.ok and icon.best_id and sem in self._verified_reads:
                raw.verified = True        # такое чтение уже подтверждалось OCR для другого кадра
        with self._lock:
            self._cache[key] = raw
            while len(self._cache) > self._cache_size:
                self._cache.popitem(last=False)
        return raw, False

    def fast_scan(self, right: np.ndarray, left: np.ndarray | None = None) -> ScanResult:
        t0 = time.perf_counter()
        t = Timings()
        out = ScanResult(right_img=right, left_img=left, timings=t, stage="fast")
        if not self._matcher.has_templates():
            out.errors.append("В базе нет эталонных иконок — добавьте их (меню → Иконки).")
            return out
        with t.span("grid"):
            grid = detect_grid(right)
        out.grid = grid
        out.notes += grid.notes
        cells = grid.filled_cells()
        for c in cells:
            img = right[c.y:c.y + c.h, c.x:c.x + c.w]
            card = CardReading(c.row, c.col, c.rect, c.partial, cell=img, key=self._key(img))
            card.raw, card.from_cache = self._read_cell_fast(img, c.partial, t)
            out.cards.append(card)
        with t.span("recalc"):
            items = self._rejudge(out.cards, None, final=False)
        out.items = sorted(items, key=lambda i: (i.status != OK, i.name))
        out.empty = not cells
        out.elapsed_ms = (time.perf_counter() - t0) * 1000.0
        t.set("fast_total", out.elapsed_ms)
        return out

    # ======================================================================
    # СУЖДЕНИЕ И АГРЕГАЦИЯ (общие для обоих режимов)
    # ======================================================================
    def _judge_card(self, card: CardReading, final: bool) -> None:
        card.reasons = []
        card.status = OK
        raw = card.raw
        if raw is None:
            card.status = CHECK
            return
        icon, cfg = raw.icon, self.cfg
        card.icon_id = icon.best_id
        card.icon_confident = icon.confident(cfg.icon_min_score, cfg.icon_min_margin)
        if (icon.best_id is None or icon.best_score < UNKNOWN_ICON_SCORE
                or icon.best_color < cfg.icon_min_color):
            card.status = UNRECOGNIZED
            card.icon_id, card.icon_confident = None, False
            card.reasons.append("иконка не найдена в базе предметов"
                                + (f" (лучшее совпадение {icon.best_score:.0%})" if icon.best_id else ""))
        elif not card.icon_confident:
            card.status = CHECK
            second = f", второй «{self._name(icon.second_id)}» {icon.second_score:.0%}" if icon.second_id else ""
            card.reasons.append(f"иконка опознана неуверенно: «{self._name(icon.best_id)}» "
                                f"{icon.best_score:.0%}{second}")
        if card.partial:
            card.status = CHECK if card.status == OK else card.status
            card.reasons.append("карточка видна не полностью — расширьте область или прокрутите сетку")
        if not raw.qty.ok:
            if raw.verified or final:
                card.status = CHECK if card.status == OK else card.status
                card.reasons.append(f"количество не прочитано ({raw.qty.reason or 'нет данных'})")
            elif card.status == OK:
                card.status = PENDING
                card.reasons.append("количество читается (OCR-проверка)")
        if raw.conflict:
            card.status = CHECK if card.status in (OK, PENDING) else card.status
            card.reasons.append("быстрое и полное распознавание расходятся: " + raw.conflict)
        card.weight_consistent = None
        it = self.catalog.items.get(icon.best_id) if icon.best_id else None
        if (raw.weight and raw.weight.ok and raw.qty.ok and card.icon_confident
                and it and it.unit_weight):
            expected = raw.qty.value * it.unit_weight
            got = raw.weight.value
            if got == expected:
                card.weight_consistent = True
            elif str(got).startswith(str(expected)) and len(str(got)) == len(str(expected)) + 1:
                card.weight_consistent = None     # «г» прочитана как цифра: не подтверждает и не мешает
            else:
                card.weight_consistent = False
            if card.weight_consistent is False:
                card.status = CHECK if card.status in (OK, PENDING) else card.status
                card.reasons.append(f"вес {raw.weight.value} г не сходится: {raw.qty.value} × "
                                    f"{it.unit_weight} г = {expected} г")

    def _rejudge(self, cards: list[CardReading], lr, final: bool) -> list[ItemResult]:
        for c in cards:
            self._judge_card(c, final)
        return self._aggregate(cards, lr, final)

    def _aggregate(self, cards: list[CardReading], lr, final: bool) -> list[ItemResult]:
        items: list[ItemResult] = []
        groups: dict[str, list[CardReading]] = {}
        for c in cards:
            if c.icon_id and c.icon_confident:
                groups.setdefault(c.icon_id, []).append(c)
            else:
                label = (f"{self._name(c.icon_id)}? (неуверенно)" if c.icon_id else "Неизвестный предмет")
                items.append(ItemResult(
                    key=f"card:{c.row}:{c.col}", name=label, item_id=None, candidate_id=c.icon_id,
                    qty=c.qty, status=c.status, reasons=list(c.reasons), cards=[(c.row, c.col)],
                    unknown=(c.status == UNRECOGNIZED),
                    price=self.catalog.items[c.icon_id].price if c.icon_id in self.catalog.items else None,
                    needs_extended=not (c.raw and c.raw.qty.ok)))

        list_ok = bool(lr and lr.read_ok)
        for item_id, cs in groups.items():
            rec = self.catalog.items.get(item_id)
            res = ItemResult(key=item_id, name=rec.name if rec else item_id, item_id=item_id,
                             price=rec.price if rec else None, cards=[(c.row, c.col) for c in cs])
            res.group_key = (item_id, tuple(sorted(_sem(c) for c in cs)))
            bad = [c for c in cs if c.status not in (OK, PENDING)]
            pend = [c for c in cs if c.status == PENDING
                    or (c.raw and not c.raw.verified and c.weight_consistent is not True)]
            qtys = [c.qty for c in cs]
            res.qty = sum(qtys) if all(q is not None for q in qtys) else None
            for c in bad:
                res.reasons += [f"слот {c.row + 1}:{c.col + 1} — {r}" for r in c.reasons]
            if bad:
                res.status = CHECK
                res.needs_extended = True
            elif pend and not final:
                res.status = PENDING
                res.reasons.append("проверяется")
            list_confirms = False
            if list_ok and res.status != PENDING:
                if item_id in lr.ambiguous:
                    res.list_issue = True
                    res.reasons.append("список слева: строка прочитана неоднозначно")
                elif item_id in lr.totals:
                    if res.qty is not None and lr.totals[item_id] == res.qty:
                        list_confirms = True
                        res.confirmed_by.append("список")
                    elif res.qty is not None:
                        res.status = CHECK
                        res.needs_extended = True
                        res.list_issue = True
                        res.reasons.append(f"список слева: {lr.totals[item_id]} шт., карточки: {res.qty} шт.")
                else:
                    res.status = CHECK
                    res.needs_extended = True
                    res.list_issue = True
                    res.reasons.append("предмета нет в списке слева (или строка не прочитана)")
            weight_confirms = bool(cs) and all(c.weight_consistent is True for c in cs)
            if weight_confirms and res.status != PENDING:
                res.confirmed_by.append("вес")
            cached = res.group_key in self._verified_groups
            if cached and res.status in (OK,):
                res.confirmed_by.append("ранее подтверждено")
            if res.status == OK and self.cfg.require_confirmation \
                    and not (list_confirms or weight_confirms or cached):
                if final:
                    res.status = CHECK
                    res.needs_extended = True
                    res.reasons.append("нет независимого подтверждения количества (список слева / вес)")
                else:
                    res.status = PENDING
                    res.reasons.append("ожидается сверка со списком слева")
            if res.price is None:
                res.status = CHECK
                res.reasons.append("не задана цена в прайс-листе")
            items.append(res)

        if list_ok:
            seen = {c.icon_id for c in cards if c.icon_id}
            for item_id, q in lr.totals.items():
                if item_id not in seen:
                    rec = self.catalog.items.get(item_id)
                    items.append(ItemResult(
                        key=item_id, name=rec.name if rec else item_id, item_id=item_id, qty=q,
                        price=rec.price if rec else None, status=CHECK,
                        reasons=["есть в списке слева, но не найден среди карточек "
                                 "(проверьте область / прокрутку сетки)"]))
            for raw in lr.unknown_lines:
                items.append(ItemResult(key=f"list:{raw}", name=raw, item_id=None, status=UNRECOGNIZED,
                                        unknown=True,
                                        reasons=["название из списка слева не найдено в прайс-листе"]))
        return items

    # ======================================================================
    # ПОЛНЫЙ РЕЖИМ (фон)
    # ======================================================================
    def _ocr_check(self, cell: np.ndarray, raw: RawRead, t: Timings) -> None:
        """Независимая проверка количества через Tesseract. Противоречие -> raw.conflict."""
        with t.span("ocr_qty"):
            if raw.qty.ok:
                # значение уже прочитано по шаблонам: нужна лишь независимая сверка (1 вызов Tesseract)
                q = read_quantity(self.ocr, cell, False, single=True)
                if not (q.ok and q.value == raw.qty.value):
                    q = read_quantity(self.ocr, cell, False)            # голосование по 2–3 вариантам
                if not (q.ok and q.value == raw.qty.value):
                    q = read_quantity(self.ocr, cell, True)             # расширенный режим
                    raw.extended = True
            else:
                # быстрое чтение не справилось: Tesseract — единственный источник, нужно голосование
                q = read_quantity(self.ocr, cell, False)
                if not q.ok:
                    q = read_quantity(self.ocr, cell, True)
                    raw.extended = True
        if raw.qty.ok:
            if q.ok and q.value != raw.qty.value:
                raw.conflict = f"быстрое чтение {raw.qty.value}, OCR {q.value}"
            elif q.ok:
                with self._lock:
                    if raw.icon.best_id:
                        self._verified_reads.add((raw.icon.best_id, raw.qty.value,
                                                  raw.weight.value if raw.weight else None))
        else:
            raw.qty, raw.qty_src = q, "ocr"
        raw.verified = True

    def _extended_check(self, cell: np.ndarray, raw: RawRead, t: Timings) -> None:
        with t.span("ocr_qty"):
            q = read_quantity(self.ocr, cell, True)
        raw.extended = True
        if q.ok and not raw.qty.ok:
            raw.qty, raw.qty_src = q, "ocr"
        elif q.ok and raw.qty.ok and q.value != raw.qty.value:
            raw.conflict = f"быстрое чтение {raw.qty.value}, расширенный OCR {q.value}"

    def _read_list_cached(self, left: np.ndarray, t: Timings, full: bool = False):
        mask = text_mask(left)
        with self._lock:
            cached = self._list_cache
        if (cached is not None and cached[0].shape == mask.shape
                and float((cv2.absdiff(cached[0], mask) > 0).mean()) < 0.004
                and (cached[1].full or not full)):
            return cached[1]
        with t.span("ocr_list"):
            lr = read_list(self.ocr, left, self._index, self.cfg.missing_x_means_one_in_list, full=full)
        with self._lock:
            self._list_cache = (mask, lr)
        return lr

    def verify(self, res: ScanResult, left: np.ndarray | None,
               abort: Callable[[], bool] | None = None) -> ScanResult | None:
        """Полная проверка быстрого результата. Возвращает None, если задание устарело (abort)."""
        t0 = time.perf_counter()
        t = res.timings.copy()
        out = dataclasses.replace(res, timings=t, stage="verified", left_img=left,
                                  cards=[dataclasses.replace(c) for c in res.cards],
                                  items=[], errors=list(res.errors), notes=list(res.notes))
        cancelled = lambda: bool(abort and abort())          # noqa: E731
        if res.errors:
            return out
        if not self.ocr.ready:
            out.errors.append(self.ocr.status.message)
            return out
        cards = out.cards
        list_future = None
        if left is not None:
            list_future = self._pool.submit(self._read_list_cached, left, t)
        try:
            futs = [self._pool.submit(self._ocr_check, c.cell, c.raw, t)
                    for c in cards if c.raw is not None and not c.raw.verified and not c.partial]
            for f in futs:
                if cancelled():
                    for g in futs:
                        g.cancel()
                    return None
                f.result()
            lr = list_future.result() if list_future is not None else None
            if cancelled():
                return None
            with t.span("recalc"):
                items = self._rejudge(cards, lr, final=True)
            # быстрое чтение списка не сошлось с карточками -> перечитываем список полностью
            if (lr is not None and left is not None and not lr.full
                    and (not lr.read_ok or any(i.list_issue for i in items))):
                if cancelled():
                    return None
                lr = self._read_list_cached(left, t, full=True)
                with t.span("recalc"):
                    items = self._rejudge(cards, lr, final=True)
            # вес стопки через Tesseract — только там, где количество не подтверждено списком
            if self.cfg.use_weight_check:
                need = {pos for it in items if "список" not in it.confirmed_by
                        and "ранее подтверждено" not in it.confirmed_by for pos in it.cards}
                todo = [c for c in cards if (c.row, c.col) in need and not c.partial
                        and c.raw is not None and c.raw.weight is None]
                if todo:
                    def rw(c: CardReading) -> None:
                        with t.span("ocr_weight"):
                            w = read_weight(self.ocr, c.cell, False)
                        if w.ok:
                            c.raw.weight = w
                    for f in [self._pool.submit(rw, c) for c in todo]:
                        f.result()
                    items = self._rejudge(cards, lr, final=True)
            # расширенный режим — только для проблемных позиций
            retry = {pos for it in items if it.needs_extended for pos in it.cards}
            redo = [c for c in cards if (c.row, c.col) in retry and not c.partial
                    and c.raw is not None and not c.raw.extended]
            if redo:
                if cancelled():
                    return None
                for f in [self._pool.submit(self._extended_check, c.cell, c.raw, t) for c in redo]:
                    f.result()
                items = self._rejudge(cards, lr, final=True)
        except OcrError as e:
            out.errors.append(str(e))
            return out
        if cancelled():
            return None

        if lr and lr.header_weight is not None:
            ws = [c.raw.weight.value for c in cards if c.raw and c.raw.weight and c.raw.weight.ok]
            if len(ws) == len(cards) and cards and sum(ws) != lr.header_weight:
                out.notes.append(f"сумма весов карточек {sum(ws)} г ≠ {lr.header_weight} г в заголовке списка")
        out.list_reading = lr
        out.items = sorted(items, key=lambda i: (i.status != OK, i.name))
        out.empty = (not cards) and not (lr and lr.totals)
        with self._lock:
            for it in out.items:
                if it.status == OK and it.group_key is not None:
                    self._verified_groups[it.group_key] = True
            while len(self._verified_groups) > MAX_VERIFIED_GROUPS:
                self._verified_groups.popitem(last=False)
        self._learn(cards, out.items)
        t.set("verify_total", (time.perf_counter() - t0) * 1000.0)
        out.elapsed_ms = res.elapsed_ms + t.get("verify_total")
        return out

    def _learn(self, cards: list[CardReading], items: list[ItemResult]) -> None:
        """Пополняет шаблоны цифр только из независимо подтверждённых значений."""
        ok_groups = {it.item_id: it for it in items if it.status == OK and it.item_id
                     and "список" in it.confirmed_by}
        for c in cards:
            raw = c.raw
            if raw is None or not raw.qty.ok or c.cell is None or raw.conflict:
                continue
            it = ok_groups.get(c.icon_id)
            trusted_by_list = it is not None and len(it.cards) == 1
            if trusted_by_list or c.weight_consistent is True:
                w = raw.weight.value if (raw.weight and c.weight_consistent is True) else None
                try:
                    self.digits.learn(c.cell, raw.qty.value, w)
                except Exception:                      # обучение — бонус, не должно ломать скан
                    pass

    # ======================================================================
    # СОВМЕСТИМЫЙ ПОЛНЫЙ СКАН (быстрый + полный подряд) — для тестов и бенчмарков
    # ======================================================================
    def scan(self, right: np.ndarray, left: np.ndarray | None = None) -> ScanResult:
        fast = self.fast_scan(right, left)
        if fast.errors:
            return fast
        if not self.ocr.ready:
            fast.errors.append(self.ocr.status.message)
            return fast
        out = self.verify(fast, left)
        return out if out is not None else fast
