"""Потоки сканирования.

  ScanWorker  (монитор + быстрый режим)  — каждые ~60 мс захват и сравнение кадра;
                при изменении мгновенно считает быстрый результат и сразу отдаёт его в GUI;
  VerifyWorker (полный режим, фон)       — Tesseract, список слева, вес; берёт только
                ПОСЛЕДНЕЕ задание (старые отбрасываются), может прерваться на лету.

Гарантии: быстрый путь никогда не ждёт OCR; одно задание проверки одновременно;
результат со старым номером изменения (seq) или поколением (generation) игнорируется.
"""
from __future__ import annotations

import logging
import threading
import time

import cv2
import numpy as np
from PySide6.QtCore import QThread, Signal

from .config import Config
from .engine import ScanEngine
from .models import OK, ScanResult
from .screen_capture import CaptureError, ScreenCapture

log = logging.getLogger(__name__)
QUAD = (148, 65)        # размер уменьшенной копии кадра для сравнения (≈ 1/4)
PIXEL_DELTA = 14        # изменение яркости, считающееся «заметным»
MIN_CHANGED_PIXELS = 6  # сколько таких пикселей = кадр изменился (ловит смену одной цифры)


def signature(img: np.ndarray) -> np.ndarray:
    g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    return cv2.resize(g, QUAD, interpolation=cv2.INTER_AREA).astype(np.int16)


def frame_changed(prev: np.ndarray | None, cur: np.ndarray) -> bool:
    if prev is None or prev.shape != cur.shape:
        return True
    return int((np.abs(prev - cur) > PIXEL_DELTA).sum()) >= MIN_CHANGED_PIXELS


class VerifyWorker(QThread):
    verified = Signal(object)

    def __init__(self, engine: ScanEngine, parent=None) -> None:
        super().__init__(parent)
        self.engine = engine
        self._cv = threading.Condition()
        self._job: tuple[ScanResult, np.ndarray | None] | None = None
        self._latest_seq = -1
        self._stop = False
        self.last_done_seq = -1

    def submit(self, res: ScanResult, left: np.ndarray | None) -> None:
        with self._cv:
            self._job = (res, left)          # старое неначатое задание заменяется новым
            self._latest_seq = res.seq
            self._cv.notify()

    def cancel_all(self) -> None:
        with self._cv:
            self._job = None
            self._latest_seq = -1

    def stop(self) -> None:
        with self._cv:
            self._stop = True
            self._cv.notify_all()
        self.wait(8000)

    def run(self) -> None:
        while True:
            with self._cv:
                while self._job is None and not self._stop:
                    self._cv.wait()
                if self._stop:
                    return
                res, left = self._job
                self._job = None
            seq = res.seq
            try:
                out = self.engine.verify(res, left,
                                         abort=lambda: self._stop or self._latest_seq != seq)
            except Exception:
                log.exception("Ошибка проверки")
                continue
            if out is None or self._latest_seq != seq:
                continue                      # устарело — не публикуем
            self.last_done_seq = seq
            self.verified.emit(out)


class ScanWorker(QThread):
    fastReady = Signal(object)       # быстрый результат (предварительный)
    verifiedReady = Signal(object)   # результат полной проверки
    failed = Signal(str)

    def __init__(self, engine: ScanEngine, cfg: Config, parent=None) -> None:
        super().__init__(parent)
        self.engine = engine
        self.cfg = cfg
        self.generation = 0
        self._stop = threading.Event()
        self._wake = threading.Event()
        self._paused = False
        self._force = True
        self._seq = 0
        self._last_error = ""
        self.verifier = VerifyWorker(engine, self)
        self.verifier.verified.connect(self._on_verified)
        self._last_fast: ScanResult | None = None
        self._last_verified: ScanResult | None = None
        self._last_verify_t = 0.0

    # ---- управление из GUI-потока ---------------------------------------------
    def start(self, *a, **k) -> None:       # noqa: D401
        self.verifier.start()
        super().start(*a, **k)

    def request_reset(self) -> None:
        """Сброс: результаты старого поколения станут недействительными, кэш очищается."""
        self.generation += 1
        self._force = True
        self._last_fast = self._last_verified = None
        self.verifier.cancel_all()
        self.engine.clear_cache()
        self._wake.set()

    def force_rescan(self) -> None:
        self._force = True
        self._wake.set()

    def set_paused(self, paused: bool) -> None:
        self._paused = paused
        if not paused:
            self._force = True
            self._wake.set()

    def stop(self) -> None:
        self._stop.set()
        self._wake.set()
        self.verifier.stop()
        if not self.wait(8000):
            log.warning("Поток сканирования не завершился вовремя")

    # ---- внутреннее -----------------------------------------------------------
    def _on_verified(self, res: ScanResult) -> None:
        self._last_verified = res
        self._last_verify_t = time.perf_counter()
        res.timings.set("change_to_verified", (time.perf_counter() - res.t_change) * 1000.0)
        self.verifiedReady.emit(res)

    def _needs_retry(self, lf: ScanResult | None) -> bool:
        lv = self._last_verified
        if lf is None or lv is None or lv.seq != lf.seq or lf.empty:
            return False
        if time.perf_counter() - self._last_verify_t < self.cfg.force_rescan_sec:
            return False
        return any(i.status != OK and not i.unknown and (i.list_issue or i.needs_extended)
                   for i in lv.items)

    def _sleep(self, seconds: float) -> None:
        self._wake.wait(max(0.0, seconds))
        self._wake.clear()

    def run(self) -> None:
        cap = ScreenCapture()
        prev = None
        try:
            while not self._stop.is_set():
                t_loop = time.perf_counter()
                interval = max(0.03, self.cfg.detect_interval_ms / 1000.0)
                try:
                    if self._paused or not self.cfg.right_region:
                        self._sleep(0.15)
                        continue
                    gen = self.generation
                    t_cap = time.perf_counter()
                    right = cap.grab(self.cfg.right_region)
                    cap_ms = (time.perf_counter() - t_cap) * 1000.0
                    t_det = time.perf_counter()
                    sig = signature(right)
                    changed = self._force or frame_changed(prev, sig)
                    det_ms = (time.perf_counter() - t_det) * 1000.0
                    if changed:
                        t_change = time.perf_counter()
                        self._force = False
                        prev = sig
                        left = cap.grab(self.cfg.left_region) if self.cfg.left_region else None
                        res = self.engine.fast_scan(right, left)
                        self._seq += 1
                        res.seq, res.generation, res.t_change = self._seq, gen, t_change
                        res.timings.set("capture", cap_ms)
                        res.timings.set("detect", det_ms)
                        res.timings.set("change_to_fast", (time.perf_counter() - t_change) * 1000.0 + cap_ms)
                        self._last_fast = res
                        self.fastReady.emit(res)
                        if not res.empty and not res.errors:
                            self.verifier.submit(res, left)
                    else:
                        lf = self._last_fast
                        if lf is not None and lf.empty:
                            self.fastReady.emit(lf)                 # для счётчика «пустой трейд»
                        elif self._needs_retry(lf):
                            # «требуется проверка» не проходит само — раз в несколько секунд
                            # перечитываем список слева заново (вдруг кадр был неудачным)
                            left = cap.grab(self.cfg.left_region) if self.cfg.left_region else None
                            self._last_verify_t = time.perf_counter()
                            self.engine.drop_list_cache()
                            self.verifier.submit(lf, left)
                    self._last_error = ""
                except CaptureError as e:
                    self._report(str(e))
                except Exception as e:
                    log.exception("Ошибка сканирования")
                    self._report(f"Ошибка сканирования: {e}")
                self._sleep(interval - (time.perf_counter() - t_loop))
        finally:
            cap.close()

    def _report(self, msg: str) -> None:
        if msg != self._last_error:
            self._last_error = msg
            self.failed.emit(msg)
