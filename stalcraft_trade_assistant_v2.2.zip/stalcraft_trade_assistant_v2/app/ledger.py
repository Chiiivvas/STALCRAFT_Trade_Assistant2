"""Инкрементальный итог: хранит позиции и обновляет сумму по РАЗНИЦЕ.

Новая сумма = предыдущая − старая стоимость позиции + новая стоимость позиции.
Защита: дубли ключей игнорируются (двойного учёта нет), результаты старого поколения
или с меньшим номером изменения (seq) отбрасываются.
"""
from __future__ import annotations

import logging
import threading
from dataclasses import dataclass, field

from .models import OK, PENDING, ItemResult

log = logging.getLogger(__name__)
CONFIRMED, PRELIM = "confirmed", "pending"


@dataclass
class LedgerUpdate:
    changed: list[str] = field(default_factory=list)
    delta_confirmed: int = 0
    delta_pending: int = 0
    duplicates: int = 0


class TradeLedger:
    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._pos: dict[str, tuple[str | None, int, ItemResult]] = {}
        self.confirmed = 0           # подтверждённая сумма
        self.pending = 0             # предварительная сумма позиций «проверяется»
        self.seq = -1
        self.generation = 0

    @property
    def confirmed_count(self) -> int:
        return sum(1 for b, _a, _i in self._pos.values() if b == CONFIRMED)

    @property
    def pending_count(self) -> int:
        return sum(1 for b, _a, _i in self._pos.values() if b == PRELIM)

    @property
    def size(self) -> int:
        return len(self._pos)

    def reset(self, generation: int | None = None) -> None:
        with self._lock:
            self._pos.clear()
            self.confirmed = self.pending = 0
            self.seq = -1
            if generation is not None:
                self.generation = generation

    @staticmethod
    def _bucket(it: ItemResult, manual: bool) -> tuple[str | None, int]:
        amount = it.amount
        if amount is None:
            return None, 0
        if it.status == OK or manual:
            return CONFIRMED, int(amount)
        if it.status == PENDING:
            return PRELIM, int(amount)
        return None, 0

    def apply(self, items: list[ItemResult], accepted: set[str] | frozenset[str] = frozenset(),
              seq: int = 0, generation: int | None = None) -> LedgerUpdate | None:
        """Возвращает None, если результат устарел (другое поколение или меньший seq)."""
        with self._lock:
            if generation is not None and generation != self.generation:
                return None
            if seq < self.seq:
                return None
            upd = LedgerUpdate()
            new: dict[str, tuple[str | None, int, ItemResult]] = {}
            for it in items:
                if it.key in new:
                    upd.duplicates += 1
                    log.warning("Дубль позиции %s проигнорирован", it.key)
                    continue
                manual = it.status != OK and it.key in accepted and it.qty is not None \
                    and it.price is not None and bool(it.item_id or it.candidate_id)
                b, a = self._bucket(it, manual)
                new[it.key] = (b, a, it)
            for key, (b, a, _it) in list(self._pos.items()):
                if key not in new:
                    self._add(b, -a, upd)
                    upd.changed.append(key)
            for key, (b, a, it) in new.items():
                old = self._pos.get(key)
                if old is None:
                    self._add(b, a, upd)
                    upd.changed.append(key)
                elif (old[0], old[1]) != (b, a):
                    self._add(old[0], -old[1], upd)
                    self._add(b, a, upd)
                    upd.changed.append(key)
            self._pos = new
            self.seq = seq
            return upd

    def _add(self, bucket: str | None, amount: int, upd: LedgerUpdate) -> None:
        if bucket == CONFIRMED:
            self.confirmed += amount
            upd.delta_confirmed += amount
        elif bucket == PRELIM:
            self.pending += amount
            upd.delta_pending += amount

    def recompute(self) -> tuple[int, int]:
        """Пересчёт с нуля — только для самопроверки/тестов."""
        with self._lock:
            c = sum(a for b, a, _ in self._pos.values() if b == CONFIRMED)
            p = sum(a for b, a, _ in self._pos.values() if b == PRELIM)
            return c, p
