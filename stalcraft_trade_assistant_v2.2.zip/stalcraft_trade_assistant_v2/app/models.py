"""Структуры данных результатов распознавания."""
from __future__ import annotations

import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass, field

import numpy as np

from .vision.grid import Grid
from .vision.icons import IconMatch
from .vision.list_reader import ListReading
from .vision.quantity import ReadResult

OK, CHECK, UNRECOGNIZED, PENDING = "ok", "check", "unrecognized", "pending"
STATUS_TEXT = {OK: "уверенно распознано", CHECK: "требуется проверка", UNRECOGNIZED: "не распознано",
               PENDING: "проверяется"}


class Timings:
    """Потокобезопасный накопитель времени этапов (мс). Для OCR в пуле — сумма по вызовам."""

    def __init__(self, data: dict[str, float] | None = None) -> None:
        self._d: dict[str, float] = dict(data or {})
        self._lock = threading.Lock()

    def add(self, name: str, ms: float) -> None:
        with self._lock:
            self._d[name] = self._d.get(name, 0.0) + ms

    def set(self, name: str, ms: float) -> None:
        with self._lock:
            self._d[name] = ms

    def get(self, name: str) -> float:
        return self._d.get(name, 0.0)

    @contextmanager
    def span(self, name: str):
        t0 = time.perf_counter()
        try:
            yield
        finally:
            self.add(name, (time.perf_counter() - t0) * 1000.0)

    def as_dict(self) -> dict[str, float]:
        with self._lock:
            return {k: round(v, 2) for k, v in self._d.items()}

    def copy(self) -> "Timings":
        return Timings(self._d)


@dataclass
class RawRead:
    """Результат чтения одной карточки (кэшируется по содержимому)."""
    icon: IconMatch
    qty: ReadResult
    weight: ReadResult | None
    extended: bool = False
    verified: bool = False              # Tesseract-перепроверка выполнена
    conflict: str = ""                  # быстрое чтение и OCR разошлись
    qty_src: str = ""                   # digits | ocr


@dataclass
class CardReading:
    row: int
    col: int
    rect: tuple[int, int, int, int]
    partial: bool
    raw: RawRead | None = None
    icon_id: str | None = None          # опознанный предмет (даже неуверенно)
    icon_confident: bool = False
    weight_consistent: bool | None = None
    status: str = OK
    reasons: list[str] = field(default_factory=list)
    from_cache: bool = False
    cell: np.ndarray | None = None
    key: str = ""                       # хэш изображения карточки

    @property
    def qty(self) -> int | None:
        return self.raw.qty.value if self.raw else None


@dataclass
class ItemResult:
    key: str                            # item_id или "card:r:c"
    name: str
    item_id: str | None                 # подтверждённый предмет
    candidate_id: str | None = None     # предполагаемый предмет (для ручного принятия)
    qty: int | None = None
    price: int | None = None
    status: str = OK
    reasons: list[str] = field(default_factory=list)
    confirmed_by: list[str] = field(default_factory=list)
    cards: list[tuple[int, int]] = field(default_factory=list)
    needs_extended: bool = False
    list_issue: bool = False            # причина сомнения — список слева (повод перечитать его полностью)
    group_key: tuple | None = None      # (предмет, состав карточек) для кэша подтверждённых групп
    unknown: bool = False               # предмета нет в прайс-листе / базе иконок

    @property
    def amount(self) -> int | None:
        if self.qty is None or self.price is None:
            return None
        return self.qty * self.price


@dataclass
class ScanResult:
    items: list[ItemResult] = field(default_factory=list)
    cards: list[CardReading] = field(default_factory=list)
    grid: Grid | None = None
    list_reading: ListReading | None = None
    empty: bool = False
    notes: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    elapsed_ms: float = 0.0
    generation: int = 0
    right_img: np.ndarray | None = None      # исходные кадры — для диагностики
    left_img: np.ndarray | None = None
    stage: str = "full"                      # fast | verified | full
    seq: int = 0                             # номер изменения кадра (для отбрасывания устаревших)
    timings: Timings = field(default_factory=Timings)
    t_change: float = 0.0                    # perf_counter момента обнаружения изменения

    @property
    def pending(self) -> bool:
        return any(i.status == PENDING for i in self.items)
