"""Быстрое распознавание цифр количества («7x») и веса («105 г») по шаблонам глифов.

Шрифт игры один и тот же для количества и веса, поэтому шаблоны общие. Глифы
нормализуются по размеру, так что чтение не зависит от масштаба интерфейса.
Время чтения — миллисекунды (Tesseract: ~95 мс на один вызов).

Принципы безопасности:
  * цифра принимается, только если совпадение с шаблоном высокое И заметно лучше второго кандидата;
  * незнакомый символ -> «не прочитано» (дальше работает Tesseract), а не догадка;
  * шаблоны пополняются только из значений, подтверждённых независимо (список слева / вес).
"""
from __future__ import annotations

import threading
from dataclasses import dataclass, field
from pathlib import Path

import cv2
import numpy as np

from . import layout
from .icons import crop_fraction

REF_CELL_H = 74.0          # высота ячейки на эталонном скриншоте 1920x1080
UP = 4.0                   # увеличение глифов (в эталонном масштабе)
GW, GH = 10, 14            # размер нормализованного глифа
TALL_MIN_H, TALL_MAX_H = 31, 60      # цифры «высокие»; x, г, к — ниже
SHORT_MIN_H, SHORT_MAX_H = 20, 31
MIN_W, MAX_W = 6, 40
DIGIT_W = 31               # типичная ширина цифры — для разделения слипшихся глифов
ACCEPT_NCC = 0.90
ACCEPT_MARGIN = 0.12
MAX_PER_DIGIT = 8
MAX_GAP_DIGITS = 18          # допустимый промежуток между цифрами (норма ≤ 13)
MAX_GAP_TAIL = {"qty": 16, "weight": 22}   # до «x» (норма ≤ 10) / до «г» (норма 13–15)


@dataclass
class Glyph:
    x: int
    y: int
    w: int
    h: int
    gray: np.ndarray
    tall: bool


@dataclass
class DigitRead:
    value: int | None = None
    text: str = ""
    min_ncc: float = 0.0
    reason: str = ""
    glyph_count: int = 0

    @property
    def ok(self) -> bool:
        return self.value is not None


def _normalize(gray: np.ndarray) -> np.ndarray:
    g = cv2.resize(gray, (GW, GH), interpolation=cv2.INTER_AREA).astype(np.float32)
    g -= g.mean()
    n = float(np.linalg.norm(g))
    return (g / n).ravel() if n > 1e-6 else g.ravel()


def _binary(box_bgr: np.ndarray, cell_h: float):
    """(gray, bin) в эталонном масштабе; длинные горизонтальные линии (свечение иконки) вырезаются."""
    f = UP * REF_CELL_H / max(cell_h, 1.0)
    g = cv2.cvtColor(box_bgr, cv2.COLOR_BGR2GRAY)
    g = cv2.resize(g, None, fx=f, fy=f, interpolation=cv2.INTER_CUBIC)
    hi = float(np.percentile(g, 99))
    _, b = cv2.threshold(g, max(50.0, 0.55 * hi), 255, cv2.THRESH_BINARY)
    lines = cv2.morphologyEx(b, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_RECT, (60, 1)))
    lines = cv2.dilate(lines, np.ones((3, 1), np.uint8))
    return g, cv2.bitwise_and(b, cv2.bitwise_not(lines))


def segment(box_bgr: np.ndarray, cell_h: float) -> list[Glyph]:
    """Разрезает текстовую область на символы (слева направо). Слипшиеся цифры делятся поровну.

    Если слева от первого символа остался заметный «осколок» (потерянная ведущая цифра),
    возвращается пустой список — чтение считается недостоверным.
    """
    if box_bgr.size == 0:
        return []
    g, b = _binary(box_bgr, cell_h)
    n, _lab, st, _ = cv2.connectedComponentsWithStats(b, 8)
    H, W = g.shape
    out: list[Glyph] = []
    accepted = set()
    for i in range(1, n):
        x, y, w, h, _a = (int(v) for v in st[i])
        if x <= 0 or y <= 0 or x + w >= W or y + h >= H:      # касается края области — не символ
            continue
        tall = TALL_MIN_H <= h <= TALL_MAX_H
        short = SHORT_MIN_H <= h < SHORT_MAX_H
        if not (tall or short) or w < MIN_W:
            continue
        accepted.add(i)
        if w <= MAX_W:
            out.append(Glyph(x, y, w, h, g[y:y + h, x:x + w], tall))
        elif tall and w <= 3 * DIGIT_W + 12:                   # слипшиеся высокие цифры
            k = max(2, round(w / DIGIT_W))
            step = w / k
            for j in range(k):
                xa, xb = int(round(x + j * step)), int(round(x + (j + 1) * step))
                out.append(Glyph(xa, y, xb - xa, h, g[y:y + h, xa:xb], True))
    out.sort(key=lambda t: t.x)
    if out:
        # осколки текста, не прошедшие фильтры, слева/между символами = часть текста потеряна
        left = out[0].x
        band_top, band_bot = min(gl.y for gl in out), max(gl.y + gl.h for gl in out)
        for i in range(1, n):
            if i in accepted:
                continue
            x, y, w, h, a = (int(v) for v in st[i])
            if a >= 30 and x > 8 and x + w <= left + 2 and y + h > band_top and y < band_bot and x + w < W - 1:
                return []
    return out


class DigitReader:
    def __init__(self, seed_dir: Path | None = None, user_dir: Path | None = None) -> None:
        self._lock = threading.Lock()
        self.templates: dict[str, list[np.ndarray]] = {}
        self.user_dir = user_dir
        for d in (seed_dir, user_dir):
            if d and Path(d).exists():
                self._load_dir(Path(d))

    def _load_dir(self, d: Path) -> None:
        for p in sorted(d.glob("*.png")):
            ch = p.name.split("_")[0]
            if ch not in "0123456789":
                continue
            data = np.fromfile(str(p), dtype=np.uint8)
            im = cv2.imdecode(data, cv2.IMREAD_GRAYSCALE)
            if im is not None:
                self.templates.setdefault(ch, []).append(_normalize(im))

    @property
    def known_digits(self) -> str:
        return "".join(sorted(self.templates))

    @property
    def ready(self) -> bool:
        return len(self.templates) >= 1

    # ---- классификация -------------------------------------------------------
    def _classify(self, gray: np.ndarray) -> tuple[str | None, float, float]:
        v = _normalize(gray)
        best: list[tuple[float, str]] = []
        for ch, ts in list(self.templates.items()):
            best.append((max(float(v @ t) for t in ts), ch))
        if not best:
            return None, 0.0, 0.0
        best.sort(reverse=True)
        s1, c1 = best[0]
        s2 = best[1][0] if len(best) > 1 else -1.0
        return c1, s1, s1 - s2

    def _read(self, box: np.ndarray, cell_h: float, kind: str) -> DigitRead:
        if not self.ready:
            return DigitRead(reason="нет шаблонов цифр")
        glyphs = segment(box, cell_h)
        digits = [g for g in glyphs if g.tall]
        tail = [g for g in glyphs if not g.tall]
        if not digits:
            return DigitRead(reason="цифры не найдены", glyph_count=len(glyphs))
        # правильная форма: цифры, затем ровно один низкий символ («x» или «г»)
        if len(tail) != 1 or tail[0].x < digits[-1].x or glyphs[-1] is not tail[0]:
            return DigitRead(reason="неожиданный набор символов", glyph_count=len(glyphs))
        if len(digits) > 7:
            return DigitRead(reason="слишком много цифр", glyph_count=len(glyphs))
        # потерянные при размытии символы дают пустой промежуток — такое чтение недостоверно
        if any(b.x - (a.x + a.w) > MAX_GAP_DIGITS for a, b in zip(digits, digits[1:])) or \
                tail[0].x - (digits[-1].x + digits[-1].w) > MAX_GAP_TAIL[kind]:
            return DigitRead(reason="пропуск между символами (часть текста не видна)", glyph_count=len(glyphs))
        text, lo = "", 1.0
        for g in digits:
            ch, s, margin = self._classify(g.gray)
            lo = min(lo, s)
            if ch is None or s < ACCEPT_NCC or margin < ACCEPT_MARGIN:
                return DigitRead(min_ncc=lo, reason="цифра не опознана (нет шаблона / низкая уверенность)",
                                 glyph_count=len(glyphs))
            text += ch
        if len(text) > 1 and text[0] == "0":
            return DigitRead(text=text, min_ncc=lo, reason="число не может начинаться с 0",
                             glyph_count=len(glyphs))
        return DigitRead(int(text), text, lo, "", len(glyphs))

    def read_qty(self, cell_bgr: np.ndarray) -> DigitRead:
        return self._read(crop_fraction(cell_bgr, layout.QTY_BOX), cell_bgr.shape[0], "qty")

    def read_weight(self, cell_bgr: np.ndarray) -> DigitRead:
        return self._read(crop_fraction(cell_bgr, layout.WEIGHT_BOX), cell_bgr.shape[0], "weight")

    # ---- обучение на подтверждённых значениях -----------------------------------
    def learn(self, cell_bgr: np.ndarray, qty: int | None, weight: int | None) -> int:
        """Добавляет глифы из карточки, значения которой подтверждены независимо. Возвращает число новых."""
        added = 0
        for box, value in ((layout.QTY_BOX, qty), (layout.WEIGHT_BOX, weight)):
            if value is None:
                continue
            ds = str(value)
            glyphs = segment(crop_fraction(cell_bgr, box), cell_bgr.shape[0])
            tall = [g for g in glyphs if g.tall]
            if len(tall) != len(ds) or sum(1 for g in glyphs if not g.tall) != 1:
                continue
            for ch, g in zip(ds, tall):
                added += self._add(ch, g.gray)
        return added

    def _add(self, ch: str, gray: np.ndarray) -> int:
        v = _normalize(gray)
        with self._lock:
            ts = self.templates.setdefault(ch, [])
            # не дублируем почти одинаковые шаблоны и не раздуваем набор
            if len(ts) >= MAX_PER_DIGIT or any(float(v @ t) > 0.985 for t in ts):
                return 0
            ts.append(v)
        if self.user_dir:
            self.user_dir.mkdir(parents=True, exist_ok=True)
            n = 1
            while (self.user_dir / f"{ch}_u{n}.png").exists():
                n += 1
            cv2.imencode(".png", cv2.resize(gray, (GW * 4, GH * 4), interpolation=cv2.INTER_AREA))[1].tofile(
                str(self.user_dir / f"{ch}_u{n}.png"))
        return 1

    def add_seed_glyph(self, ch: str, gray: np.ndarray, out_dir: Path) -> None:
        """Для tools/build_digit_seeds.py: сохранить эталонный глиф в assets/digits."""
        out_dir.mkdir(parents=True, exist_ok=True)
        n = 1
        while (out_dir / f"{ch}_s{n}.png").exists():
            n += 1
        small = cv2.resize(gray, (GW * 4, GH * 4), interpolation=cv2.INTER_AREA)
        cv2.imencode(".png", small)[1].tofile(str(out_dir / f"{ch}_s{n}.png"))
