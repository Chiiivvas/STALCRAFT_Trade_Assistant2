"""Строит эталонные глифы цифр из реальных скриншотов (известные подтверждённые значения)."""
import pathlib, shutil, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from tools._scenarios import scenarios
from app.vision import layout
from app.vision.digits import DigitReader, segment
from app.vision.grid import detect_grid
from app.vision.icons import crop_fraction

# (кадр, количества, веса) — значения проверены вручную и сходятся со списком слева
LABELED = [("A", [7, 6, 1, 1, 10, 12], [105, 90, 15, 10, 150, 180]),
           ("B", [2, 6, 4, 6], [30, 90, 60, 90])]


def labeled_cards():
    S = scenarios()
    for name, qs, ws in LABELED:
        fr = S[name][0]
        for c, q, w in zip(detect_grid(fr).filled_cells(), qs, ws):
            yield fr[c.y:c.y + c.h, c.x:c.x + c.w], q, w


if __name__ == "__main__":
    out = pathlib.Path(__file__).resolve().parent.parent / "assets" / "digits"
    shutil.rmtree(out, ignore_errors=True)
    r = DigitReader()
    n = 0
    for cell, q, w in labeled_cards():
        for box, v in ((layout.QTY_BOX, q), (layout.WEIGHT_BOX, w)):
            gl = segment(crop_fraction(cell, box), cell.shape[0])
            tall = [g for g in gl if g.tall]
            if len(tall) == len(str(v)):
                for ch, g in zip(str(v), tall):
                    r.add_seed_glyph(ch, g.gray, out); n += 1
    print("glyphs saved:", n, sorted(p.name for p in out.glob("*.png"))[:60])
