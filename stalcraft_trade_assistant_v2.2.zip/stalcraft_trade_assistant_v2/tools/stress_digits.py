import cv2, numpy as np, itertools
from tools.build_digit_seeds import labeled_cards
from app.vision.digits import DigitReader
from app.paths import ASSETS_DIR
r=DigitReader(ASSETS_DIR/'digits'); cards=list(labeled_cards())
rng=np.random.default_rng(1)
def jpeg(x,q): return cv2.imdecode(cv2.imencode('.jpg',x,[cv2.IMWRITE_JPEG_QUALITY,q])[1],1)
def degrade(cell,sc,blur,jq,alpha,noise):
    x=cv2.resize(cell,None,fx=sc,fy=sc,interpolation=cv2.INTER_CUBIC if sc>=1 else cv2.INTER_AREA)
    if blur: x=cv2.GaussianBlur(x,(5,5),blur)
    if noise: x=np.clip(x.astype(np.float32)+rng.normal(0,noise,x.shape),0,255).astype(np.uint8)
    if jq: x=jpeg(x,jq)
    return cv2.convertScaleAbs(x,alpha=alpha,beta=0)
def run(grid,label):
    tot=ok=un=wr=0; bad=[]
    for sc,blur,jq,alpha,noise in grid:
        for idx,(cell,q,w) in enumerate(cards):
            x=degrade(cell,sc,blur,jq,alpha,noise)
            for truth,fn in ((q,r.read_qty),(w,r.read_weight)):
                d=fn(x); tot+=1
                if d.ok and d.value==truth: ok+=1
                elif d.ok: wr+=1; bad.append((sc,blur,jq,alpha,noise,idx,truth,d.value,round(d.min_ncc,2)))
                else: un+=1
    print(f'{label}: total={tot} correct={ok} ({ok/tot:.0%}) unread(safe)={un} ({un/tot:.0%}) WRONG={wr}')
    for b in bad[:8]: print('   WRONG',b)
run(itertools.product((0.6,0.75,0.9,1.0,1.1,1.25,1.5,2.0),(0,0.6,1.0,1.5,2.5),(0,50),(0.7,1.0,1.2),(0,6)),'BRUTAL grid')
run(itertools.product((0.9,1.0,1.1,1.25,1.5),(0,0.5),(0,85),(0.9,1.0,1.1),(0,)),'REALISTIC grid (scale 0.9-1.5, light blur/jpeg)')
