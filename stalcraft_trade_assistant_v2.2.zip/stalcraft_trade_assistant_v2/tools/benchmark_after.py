"""Замер «ПОСЛЕ» оптимизации на тех же сценариях, что tools/baseline_before.py. Пишет docs/performance.md."""
import json, pathlib, statistics as st, sys, tempfile, time
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from tools._scenarios import scenarios
from app.config import Config
from app.engine import ScanEngine
from app.paths import ASSETS_DIR
from app.price_database import PriceDatabase
from app.vision.digits import DigitReader
from app.vision.grid import detect_grid
from app.vision.ocr import OcrEngine
from app.worker import frame_changed, signature

PRICES = {"slastena": 8300, "kuborbuz": 1000, "limonnik": 1000, "solevik": 1500, "dust": 280}


def ms(f, n=1):
    t = time.perf_counter()
    for _ in range(n):
        r = f()
    return (time.perf_counter() - t) * 1000 / n, r


def main():
    S = scenarios()
    ocr = OcrEngine(None)
    tmp = pathlib.Path(tempfile.mkdtemp())
    db = PriceDatabase(tmp / "i.db", tmp / "ic")
    for it in db.items():
        db.set_price(it.id, PRICES[it.id])

    def fresh():
        e = ScanEngine(Config(), ocr, DigitReader(ASSETS_DIR / "digits", tmp / "d"))
        e.set_catalog(db.catalog())
        return e

    ra, la = S["A"]
    rb, lb = S["B"]
    micro = {}
    sig = signature(ra)
    micro["frame_change_detect_ms"] = ms(lambda: frame_changed(sig, signature(S["changed"])), 200)[0]
    micro["grid_detect_ms"] = ms(lambda: detect_grid(ra), 30)[0]
    e = fresh()
    cell = next(c for c in detect_grid(ra).cells if c.filled)
    img = ra[cell.y:cell.y + cell.h, cell.x:cell.x + cell.w]
    micro["icon_match_ms"] = ms(lambda: e._matcher.match(img), 100)[0]
    micro["digits_qty_plus_weight_ms"] = ms(lambda: (e.digits.read_qty(img), e.digits.read_weight(img)), 200)[0]

    names = ["cold_A", "after_add", "after_qty_change", "after_remove", "empty_trade", "unchanged_rescan"]
    fast = {k: [] for k in names}
    ver = {k: [] for k in ("cold_A_with_list", "cold_A_no_list", "after_add", "after_qty_change",
                           "after_remove", "transition_A_to_B_with_list")}
    for _ in range(5):
        e = fresh()
        fast["cold_A"].append(ms(lambda: e.fast_scan(ra, None))[0])
        fast["unchanged_rescan"].append(ms(lambda: e.fast_scan(ra, None))[0])
        fast["after_add"].append(ms(lambda: e.fast_scan(S["added"], None))[0])
        fast["after_qty_change"].append(ms(lambda: e.fast_scan(S["changed"], None))[0])
        fast["after_remove"].append(ms(lambda: e.fast_scan(S["removed"], None))[0])
        fast["empty_trade"].append(ms(lambda: e.fast_scan(S["empty"], None))[0])
    for _ in range(3):
        e = fresh(); f = e.fast_scan(ra, la)
        ver["cold_A_with_list"].append(ms(lambda: e.verify(f, la))[0])
        e = fresh(); f = e.fast_scan(ra, None)
        ver["cold_A_no_list"].append(ms(lambda: e.verify(f, None))[0])
        for key, fr in (("after_add", "added"), ("after_qty_change", "changed"), ("after_remove", "removed")):
            f = e.fast_scan(S[fr], None); ver[key].append(ms(lambda: e.verify(f, None))[0])
        e = fresh(); e.scan(ra, la)
        f = e.fast_scan(rb, lb); ver["transition_A_to_B_with_list"].append(ms(lambda: e.verify(f, lb))[0])
    out = {"micro_ms": {k: round(v, 3) for k, v in micro.items()},
           "fast_ms_median": {k: round(st.median(v), 2) for k, v in fast.items()},
           "verify_background_ms_median": {k: round(st.median(v), 1) for k, v in ver.items()},
           "detect_interval_ms": Config().detect_interval_ms}
    pathlib.Path("docs/benchmark_after.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")

    before = json.loads(pathlib.Path("docs/baseline_before.json").read_text(encoding="utf-8"))
    b = before["scan_ms_median"]
    rows = [
        ("Интервал проверки кадра", f"{before['detect_interval_ms']} мс", f"{out['detect_interval_ms']} мс"),
        ("Сравнение кадров (обнаружение изменения)", f"{before['frame_diff_ms']} мс", f"{micro['frame_change_detect_ms']:.2f} мс"),
        ("Холодный старт, 6 карточек (итог на экране)", f"{b['cold_A_no_list']:.0f} мс", f"{out['fast_ms_median']['cold_A']:.0f} мс"),
        ("Добавлен предмет → итог обновлён", f"{b['after_add']:.0f} мс", f"{out['fast_ms_median']['after_add']:.0f} мс"),
        ("Изменено количество → итог обновлён", f"{b['after_qty_change']:.0f} мс", f"{out['fast_ms_median']['after_qty_change']:.0f} мс"),
        ("Удалён предмет → итог обновлён", f"{b['after_remove']:.0f} мс", f"{out['fast_ms_median']['after_remove']:.0f} мс"),
        ("Пустой трейд", f"{b['empty_trade']:.0f} мс", f"{out['fast_ms_median']['empty_trade']:.0f} мс"),
        ("Кадр не менялся", f"{b['unchanged_rescan']:.0f} мс", "0 (скан не запускается)"),
    ]
    md = ["# Производительность: до и после оптимизации", "",
          "Окружение замера: Linux-песочница, **1 ядро CPU**, без реального экрана. Медианы по повторным запускам "
          "на реальных кадрах (сценарии `tools/_scenarios.py`). Захват экрана (mss) здесь не измерялся.", "",
          "## Время до обновления итога на экране", "",
          "| Сценарий | До | После (быстрый режим) |", "|---|---:|---:|"]
    md += [f"| {a} | {x} | {y} |" for a, x, y in rows]
    md += ["", "## Фоновая проверка (полный режим, GUI не блокирует)", "",
           "| Сценарий | До (блокировало результат) | После (в фоне) |", "|---|---:|---:|",
           f"| Холодный старт со списком слева | {b['cold_A_with_list']:.0f} мс | {out['verify_background_ms_median']['cold_A_with_list']:.0f} мс |",
           f"| Холодный старт без списка (по весу) | {b['cold_A_no_list']:.0f} мс | {out['verify_background_ms_median']['cold_A_no_list']:.0f} мс |",
           f"| Добавление предмета | {b['after_add']:.0f} мс | {out['verify_background_ms_median']['after_add']:.0f} мс |",
           f"| Смена количества | {b['after_qty_change']:.0f} мс | {out['verify_background_ms_median']['after_qty_change']:.0f} мс |",
           f"| Переход к другому трейду со списком | {b['transition_A_to_B_with_list']:.0f} мс | {out['verify_background_ms_median']['transition_A_to_B_with_list']:.0f} мс |",
           "", "## Микро-замеры одного этапа (после)", "", "| Этап | Время |", "|---|---:|"]
    md += [f"| {k} | {v:.3f} мс |" for k, v in micro.items()]
    md += ["", f"Один вызов Tesseract (до оптимизации — основа любого чтения): {before['tesseract_call_ms']} мс."]
    pathlib.Path("docs/performance.md").write_text("\n".join(md), encoding="utf-8")
    print("\n".join(md))


main()
