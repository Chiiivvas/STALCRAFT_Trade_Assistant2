"""Общие сценарии трейда для бенчмарка: кадры собираются из реальных скриншотов."""
import pathlib
import cv2
import numpy as np
from app.vision.grid import detect_grid

FIX = pathlib.Path(__file__).resolve().parent.parent / "tests" / "fixtures"
RIGHT = (323, 598, 594, 260)
LEFT = (95, 565, 185, 160)


def crop(img, box):
    x, y, w, h = box
    return img[y:y + h, x:x + w].copy()


def load():
    a = cv2.imread(str(FIX / "trade_full_1920x1080.png"))
    b = cv2.imread(str(FIX / "trade_unknown_green.png"))
    return a, b


def slot(frame, row, col):
    g = detect_grid(frame)
    return next(c for c in g.cells if c.row == row and c.col == col)


def paste(frame, src_frame, src_rc, dst_rc):
    """Скопировать карточку из src_frame (row,col) в слот dst_rc кадра frame."""
    s, d = slot(src_frame, *src_rc), slot(frame, *dst_rc)
    out = frame.copy()
    out[d.y:d.y + d.h, d.x:d.x + d.w] = src_frame[s.y:s.y + s.h, s.x:s.x + s.w]
    return out


def scenarios():
    """Возвращает кадры: A (6 карточек), + добавление, смена количества, удаление, пусто."""
    a, b = load()
    ra, la = crop(a, RIGHT), crop(a, LEFT)
    rb, lb = crop(b, RIGHT), crop(b, LEFT)
    added = paste(ra, rb, (0, 2), (0, 6))        # + новая карточка «куборбуз x4» (раньше не встречалась)
    changed = paste(ra, rb, (0, 0), (0, 5))      # слот 6: «солевик 12x» -> «солевик 2x»
    removed = paste(ra, ra, (0, 6), (0, 3))      # слот 4 (пыль) -> пустой слот
    empty = crop(a, (323, 190, 593, 260))        # собственная пустая сетка
    return dict(A=(ra, la), B=(rb, lb), added=added, changed=changed, removed=removed,
                empty=empty)
