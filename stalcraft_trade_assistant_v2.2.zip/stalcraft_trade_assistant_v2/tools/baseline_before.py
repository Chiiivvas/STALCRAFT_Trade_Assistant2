"""Замер «ДО» оптимизации: текущий движок (полный скан при любом изменении)."""
import json, pathlib, statistics as st, sys, tempfile, time
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
import cv2
from tools._scenarios import scenarios
from app.config import Config
from app.engine import ScanEngine
from app.price_database import PriceDatabase
from app.vision.grid import detect_grid
from app.vision.ocr import OcrEngine, light_text_variants

PRICES = {"slastena": 8300, "kuborbuz": 1000, "limonnik": 1000, "solevik": 1500, "dust": 280}


def ms(f, n=1):
    t = time.perf_counter()
    for _ in range(n):
        r = f()
    return (time.perf_counter() - t) * 1000 / n, r


def main():
    S = scenarios()
    ocr = OcrEngine(None)
    tmp = pathlib.Path(tempfile.mkdtemp())
    db = PriceDatabase(tmp / "i.db", tmp / "ic")
    for it in db.items():
        db.set_price(it.id, PRICES[it.id])

    def fresh():
        e = ScanEngine(Config(), ocr)
        e.set_catalog(db.catalog())
        return e

    out = {}
    ra, la = S["A"]
    out["grid_detect_ms"] = ms(lambda: detect_grid(ra), 20)[0]
    cell = next(c for c in detect_grid(ra).cells if c.filled)
    img = ra[cell.y:cell.y + cell.h, cell.x:cell.x + cell.w]
    e = fresh()
    out["icon_match_ms"] = ms(lambda: e._matcher.match(img), 50)[0]
    v = light_text_variants(img[:20, 22:])["p99"]
    out["tesseract_call_ms"] = ms(lambda: ocr.image_to_text(v, "eng", 7, "0123456789xX"), 6)[0]
    out["frame_diff_ms"] = ms(lambda: cv2.resize(cv2.cvtColor(ra, cv2.COLOR_BGR2GRAY), (96, 48)), 50)[0]

    runs = {k: [] for k in ("cold_A_with_list", "cold_A_no_list", "after_add", "after_qty_change",
                            "after_remove", "empty_trade", "unchanged_rescan", "transition_A_to_B_with_list")}
    for _ in range(3):
        e = fresh(); runs["cold_A_with_list"].append(ms(lambda: e.scan(ra, la))[0])
        runs["unchanged_rescan"].append(ms(lambda: e.scan(ra, la))[0])
        e = fresh(); runs["cold_A_no_list"].append(ms(lambda: e.scan(ra, None))[0])
        runs["after_add"].append(ms(lambda: e.scan(S["added"], None))[0])
        runs["after_qty_change"].append(ms(lambda: e.scan(S["changed"], None))[0])
        runs["after_remove"].append(ms(lambda: e.scan(S["removed"], None))[0])
        runs["empty_trade"].append(ms(lambda: e.scan(S["empty"], None))[0])
        e = fresh(); e.scan(ra, la)
        rb, lb = S["B"]
        runs["transition_A_to_B_with_list"].append(ms(lambda: e.scan(rb, lb))[0])
    out["scan_ms_median"] = {k: round(st.median(v), 1) for k, v in runs.items()}
    out["detect_interval_ms"] = Config().scan_interval_ms
    out["tesseract_calls_per_new_card_fast"] = "2-3 (кол-во) + 2-3 (вес, если нет списка)"
    out["grid_detect_ms"] = round(out["grid_detect_ms"], 2)
    for k in ("icon_match_ms", "tesseract_call_ms", "frame_diff_ms"):
        out[k] = round(out[k], 2)
    pathlib.Path("docs/baseline_before.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(out, ensure_ascii=False, indent=2))


main()
