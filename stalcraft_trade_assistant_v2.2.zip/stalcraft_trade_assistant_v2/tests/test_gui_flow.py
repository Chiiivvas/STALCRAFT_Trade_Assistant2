import os, time
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
import pytest
from PySide6.QtGui import QGuiApplication
from PySide6.QtWidgets import QApplication

from tools._scenarios import scenarios
from app.config import ConfigStore
from app.gui.main_window import MainWindow
from app.models import PENDING

BASE = 7 * 8300 + 6000 + 11000 + 280 + 18000


@pytest.fixture()
def win(qapp, db, engine, ocr, tmp_path):
    store = ConfigStore(tmp_path / "config.json")
    w = MainWindow(store, db, ocr, engine)        # поток-монитор запущен, но области нет — экран не читается
    yield w
    w.close()


def feed(w, res, seq):
    res.seq, res.generation = seq, w.worker.generation
    return res


def rows(w):
    return [w.table.item(r, 0).text() for r in range(w.table.rowCount())]


def digits(txt):
    return int("".join(c for c in txt if c.isdigit()) or 0)


def test_fast_result_shows_total_and_check_indicator_then_verified(win, engine):
    S = scenarios(); ra, la = S["A"]
    fast = feed(win, engine.fast_scan(ra, la), 1)
    t = time.perf_counter(); win.on_fast(fast); render_ms = (time.perf_counter() - t) * 1000
    assert render_ms < 100                                          # отрисовка не блокирует интерфейс
    assert win.table.rowCount() == 5 and digits(win.total.text()) == BASE   # подтверждено весом сразу
    assert "идёт проверка" in win.check_lbl.text()                  # проверка новых изменений ещё идёт
    win.copy_total()
    assert "Идёт проверка" in win.status.text()                     # пока идёт проверка — не копируем
    ver = engine.verify(fast, la)
    win.on_verified(ver)
    assert "проверено" in win.check_lbl.text() and digits(win.total.text()) == BASE
    assert win.count_lbl.text().startswith("Распознано: 5")
    win.copy_total()
    assert QGuiApplication.clipboard().text() == str(BASE)          # в буфере только число


def test_add_remove_change_in_gui(win, engine):
    S = scenarios(); seq = 0
    for frame, total, n in ((S["A"][0], BASE, 5), (S["added"], BASE + 4000, 5),
                            (S["changed"], BASE - 15000, 5), (S["removed"], BASE - 280, 4)):
        seq += 1
        win.on_fast(feed(win, engine.fast_scan(frame), seq))
        assert digits(win.total.text()) == total and win.table.rowCount() == n
        assert (win.ledger.confirmed, win.ledger.pending) == win.ledger.recompute()


def test_empty_trade_clears_after_consecutive_empty_frames(win, engine):
    S = scenarios()
    win.on_fast(feed(win, engine.fast_scan(S["A"][0]), 1))
    assert win.table.rowCount() == 5
    empty = feed(win, engine.fast_scan(S["empty"]), 2)
    for _ in range(win.cfg.empty_scans_to_clear):
        win.on_fast(empty)
    assert win.table.rowCount() == 0 and digits(win.total.text()) == 0


def test_stale_results_are_ignored(win, engine):
    S = scenarios()
    new = feed(win, engine.fast_scan(S["changed"]), 5)
    old = feed(win, engine.fast_scan(S["A"][0]), 4)
    win.on_fast(new); win.on_fast(old)                              # «старый» результат пришёл позже
    assert digits(win.total.text()) == BASE - 15000
    win.on_verified(feed(win, engine.verify(old, None), 4))         # и его проверка — тоже
    assert digits(win.total.text()) == BASE - 15000
    win.reset()                                                     # сброс: результат до сброса игнорируется
    stale = new; stale.generation = win.worker.generation - 1
    win.on_fast(stale)
    assert win.table.rowCount() == 0 and digits(win.total.text()) == 0


def test_pending_items_not_in_confirmed_total(win, engine, tmp_path):
    from app.vision.digits import DigitReader
    engine.digits = DigitReader(None, tmp_path / "none")
    S = scenarios(); ra, la = S["A"]
    win.on_fast(feed(win, engine.fast_scan(ra, la), 1))
    assert all("⏳" in t for t in rows(win)) and digits(win.total.text()) == 0
