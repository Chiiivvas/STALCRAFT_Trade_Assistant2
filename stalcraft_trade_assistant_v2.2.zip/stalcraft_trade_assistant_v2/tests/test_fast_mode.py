import threading, time
import numpy as np
import pytest

from tools._scenarios import scenarios
from .conftest import PRICES
from app.ledger import TradeLedger
from app.models import CHECK, OK, PENDING, ItemResult, ScanResult
from app.paths import ASSETS_DIR
from app.trade_calculator import calculate
from app.vision.digits import DigitReader
from app.vision.quantity import ReadResult


@pytest.fixture(scope="module")
def S():
    return scenarios()


def amount(res):
    return sum(i.amount for i in res.items if i.status == OK and i.amount is not None)


# ---- быстрый путь не использует Tesseract ----------------------------------------
def test_fast_path_never_calls_tesseract(engine, S, monkeypatch):
    def boom(*a, **k):
        raise AssertionError("Tesseract вызван в быстром режиме")
    monkeypatch.setattr(engine.ocr, "image_to_text", boom)
    ra, _ = S["A"]
    res = engine.fast_scan(ra)
    assert res.stage == "fast" and not res.errors
    assert {i.name: i.qty for i in res.items} == {"Мякоть сластены": 7, "Мякоть куборбуза": 6,
                                                   "Мякоть лимонника": 11, "Аномальная пыль": 1,
                                                   "Мякоть солевика": 12}
    assert amount(res) == 7 * 8300 + 6000 + 11000 + 280 + 18000        # подтверждено весом


def test_fast_path_latency_for_known_cards(engine, S):
    ra, _ = S["A"]
    engine.fast_scan(ra)                                    # прогрев
    t = time.perf_counter()
    for _ in range(20):
        engine.fast_scan(ra)
    assert (time.perf_counter() - t) / 20 * 1000 < 30        # цель ≤ 100 мс, фактически на порядок меньше


# ---- кэш: неизменившиеся карточки не распознаются повторно -------------------------------
def test_unchanged_cards_are_not_reread(engine, S, monkeypatch):
    ra, _ = S["A"]
    engine.fast_scan(ra)
    calls = []
    orig = engine.digits.read_qty
    monkeypatch.setattr(engine.digits, "read_qty", lambda c: calls.append(1) or orig(c))
    engine.fast_scan(ra)
    assert calls == []


def test_only_changed_card_is_reprocessed(engine, S, monkeypatch):
    ra, _ = S["A"]
    engine.fast_scan(ra)
    calls = []
    orig = engine.digits.read_qty
    monkeypatch.setattr(engine.digits, "read_qty", lambda c: calls.append(1) or orig(c))
    engine.fast_scan(S["changed"])                          # изменилась одна карточка из шести
    assert len(calls) == 1


# ---- добавление / удаление / смена количества: итог обновляется по разнице -------------------------
def test_add_remove_change_sequence_with_incremental_ledger(engine, S):
    ra, _ = S["A"]
    ledger = TradeLedger()
    seq = 0
    base = 7 * 8300 + 6000 + 11000 + 280 + 18000
    steps = [
        (ra, base),
        (S["added"], base + 4 * 1000),                      # + «куборбуз x4» (тот же предмет, 6+4 шт.)
        (S["changed"], base - 10 * 1500),                   # солевик 12 -> 2
        (S["removed"], base - 280),                         # пыль убрана
        (ra, base),                                         # всё вернули
    ]
    for frame, expected in steps:
        seq += 1
        res = engine.fast_scan(frame)
        upd = ledger.apply(res.items, seq=seq, generation=0)
        assert upd is not None
        assert ledger.confirmed == expected == amount(res) == calculate(res.items).total
        assert (ledger.confirmed, ledger.pending) == ledger.recompute()     # итог по разнице == пересчёт с нуля
    # добавленный предмет того же вида не создал вторую строку (нет двойного учёта)
    res = engine.fast_scan(S["added"])
    assert sum(1 for i in res.items if i.name == "Мякоть куборбуза") == 1


def test_ledger_changes_only_touched_position(engine, S):
    ledger = TradeLedger()
    ledger.apply(engine.fast_scan(S["A"][0]).items, seq=1, generation=0)
    upd = ledger.apply(engine.fast_scan(S["changed"]).items, seq=2, generation=0)
    assert upd.changed == ["solevik"] and upd.delta_confirmed == -10 * 1500


def test_empty_trade_fast(engine, S):
    res = engine.fast_scan(S["empty"])
    assert res.empty and res.items == []


# ---- ledger: защита от устаревших результатов и дублей --------------------------------------------
def test_ledger_rejects_stale_and_duplicates():
    mk = lambda k, q, st=OK: ItemResult(k, k, k, qty=q, price=10, status=st)
    L = TradeLedger()
    assert L.apply([mk("a", 2)], seq=5, generation=0) is not None and L.confirmed == 20
    assert L.apply([mk("a", 9)], seq=4, generation=0) is None and L.confirmed == 20      # старый seq
    assert L.apply([mk("a", 9)], seq=6, generation=7) is None and L.confirmed == 20      # старое поколение
    upd = L.apply([mk("a", 2), mk("a", 2)], seq=7, generation=0)                         # дубль ключа
    assert upd.duplicates == 1 and L.confirmed == 20
    L.apply([mk("a", 2, PENDING)], seq=8, generation=0)
    assert (L.confirmed, L.pending) == (0, 20)                                           # проверяется ≠ подтверждено


# ---- быстрый и полный режимы противоречат друг другу -> «требуется проверка» ---------------------------
def test_fast_full_disagreement_marks_check(engine, S, monkeypatch):
    ra, _ = S["A"]
    fast = engine.fast_scan(ra)
    import app.engine as E
    real = E.read_quantity

    def liar(ocr, cell, extended=False, single=False):
        r = real(ocr, cell, extended, single)
        return ReadResult(9, ["9x"], {9: 3}, 1.0, "fake") if r.value == 7 else r      # «OCR видит 9 вместо 7»
    monkeypatch.setattr(E, "read_quantity", liar)
    out = engine.verify(fast, None)
    sl = next(i for i in out.items if i.name == "Мякоть сластены")
    assert sl.status == CHECK and any("расходятся" in r for r in sl.reasons)
    assert amount(out) == amount(fast) - 7 * 8300                                     # в итог не входит


# ---- предварительный статус «проверяется»: цифры не прочитаны -> ждём OCR -----------------------------
def test_unreadable_quantity_is_pending_then_confirmed(engine, S, tmp_path):
    engine.digits = DigitReader(None, tmp_path / "empty_digits")          # шаблонов нет — быстрый режим «слепой»
    ra, la = S["A"]
    fast = engine.fast_scan(ra, la)
    assert all(i.status == PENDING and i.qty is None for i in fast.items)
    L = TradeLedger(); L.apply(fast.items, seq=1, generation=0)
    assert L.confirmed == 0                                                 # неподтверждённое не в итоге
    out = engine.verify(fast, la)
    assert amount(out) == 7 * 8300 + 6000 + 11000 + 280 + 18000
    assert engine.digits.known_digits                                       # и шаблоны цифр дообучились


def test_learning_adds_templates_only_from_confirmed_values(engine, S, tmp_path):
    engine.digits = DigitReader(ASSETS_DIR / "digits", tmp_path / "ud")
    before = sum(len(v) for v in engine.digits.templates.values())
    out = engine.scan(*S["B"])
    assert amount(out) == 4 * 1000 + 6 * 8300 + 2 * 1500
    assert sum(len(v) for v in engine.digits.templates.values()) >= before


def test_verify_result_stale_returns_none(engine, S):
    ra, la = S["A"]
    assert engine.verify(engine.fast_scan(ra, la), la, abort=lambda: True) is None


# ---- обнаружение изменений кадра ---------------------------------------------------------------
def test_frame_change_detection(S):
    from app.worker import frame_changed, signature
    ra, _ = S["A"]
    a = signature(ra)
    assert not frame_changed(a, signature(ra.copy()))
    noisy = np.clip(ra.astype(np.int16) + np.random.default_rng(0).integers(-2, 3, ra.shape), 0, 255).astype(np.uint8)
    assert not frame_changed(a, signature(noisy))                          # шум сенсора/сжатия — не изменение
    for name in ("added", "changed", "removed"):
        assert frame_changed(a, signature(S[name])), name                  # одна карточка = изменение


# ---- потоки: быстрый результат не ждёт полной проверки -----------------------------------------------
def test_worker_fast_result_does_not_wait_for_slow_verify(monkeypatch, qapp):
    import app.worker as W
    from app.config import Config
    qa = qapp
    state = {"frame": 0}

    class FakeCap:
        def grab(self, r):
            return np.full((60, 60, 3), 40 + 60 * state["frame"], np.uint8)
        def close(self): pass

    class FakeEngine:
        verify_started, verify_aborted, active = [], [], 0
        def fast_scan(self, r, l=None):
            return ScanResult(stage="fast")
        def verify(self, res, left, abort=None):
            FakeEngine.verify_started.append(res.seq)
            for _ in range(20):                                          # медленная «проверка» ~1 с
                if abort and abort():
                    FakeEngine.verify_aborted.append(res.seq); return None
                time.sleep(0.05)
            out = ScanResult(stage="verified"); out.seq, out.generation = res.seq, res.generation
            out.t_change = res.t_change
            return out
        def clear_cache(self): pass
        def drop_list_cache(self): pass

    monkeypatch.setattr(W, "ScreenCapture", FakeCap)
    cfg = Config(right_region=[0, 0, 60, 60], detect_interval_ms=40)
    w = W.ScanWorker(FakeEngine(), cfg)
    fast, ver = [], []
    w.fastReady.connect(lambda r: fast.append((r.seq, time.perf_counter())))
    w.verifiedReady.connect(lambda r: ver.append(r.seq))
    w.start()
    def pump(sec):
        end = time.time() + sec
        while time.time() < end: qa.processEvents(); time.sleep(0.01)
    pump(0.3)                                                              # первый кадр
    t_change = time.perf_counter(); state["frame"] = 1                     # «изменили трейд», проверка №1 ещё идёт
    pump(0.25)
    state["frame"] = 2                                                     # ещё изменение: №1/№2 устарели
    pump(2.5)
    w.stop()
    assert len(fast) >= 3
    seq2 = fast[1][0]
    assert fast[1][1] - t_change < 0.25                                    # быстрый результат — сразу, не ждёт проверку
    assert ver == [fast[-1][0]]                                            # опубликована только проверка последнего изменения
    assert FakeEngine.verify_aborted                                       # старая проверка прервана на лету
    assert not w.isRunning() and not w.verifier.isRunning()
